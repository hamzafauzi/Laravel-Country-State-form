<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomController;
use App\Models\User;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login',[CustomController::class,'login']);
Route::get('/registration', [CustomController::class,'registration']);
Route::post('/register-user', [CustomController::class,'registerUser'])->name('register-user'); 
Route::post('/login-user', [CustomController::class, 'loginUser'])->name('login-user');
Route::get('/dashboard',[CustomController::class,'dashboard'])->middleware('isLoggedIn');
Route::get('/logout',[CustomController::class,'logout']);
Route::get('/registration',[CustomController::class,'showPage']);
Route::get('/edit/{id}',[CustomController::class, 'getStudentById']);
Route::put('/update', [CustomController::class, 'updateStudent'])->name('user-update');
Route::get('/state/{idCountry}',[CustomController::class,'state'])->name('state');



