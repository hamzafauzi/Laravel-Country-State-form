<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  </head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4" style="margin-top: 20px">
                <h1>Welcome to the dashboard</h1>
                <hr>
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Country</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><?php echo e($data->id); ?></td>
                        <td><?php echo e($data->fname); ?></td>
                        <td><?php echo e($data->lname); ?></td>
                        <td><?php echo e($data->email); ?></td>
                        <td><?php echo e($data->country->country_name); ?></td>
                        <td>
                          <a href="javascript:void(0)" onclick="editStudent(<?php echo e($data->id); ?>)" class="btn btn-primary btn-sm">Edit</a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <a href="logout">Logout</a>
            </div>
        </div>
    </div>

    
    <div id="studentEditModal" class="modal fade">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h1 class="modal-title">Edit Form</h1>
              </div>
              <div class="modal-body">
                  <form id="studentEditForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="id" name="id"/>
                      <div class="form-group">
                          <label class="control-label">First name</label>
                          <div>
                              <input type="text" class="form-control input-lg" name="fname" id="fname" value="">
                          </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label">Last name</label>
                        <div>
                            <input type="text" class="form-control input-lg" name="lname" id="lname" value="">
                        </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label">Email</label>
                      <div>
                          <input type="email" class="form-control input-lg" name="email" id="email" value="">
                      </div>
                    </div>
                    <div class="form-group">
                      <select name="country_id" id="country">
                          <option value="" disabled selected><?php echo e('Select Country'); ?></option>;
                          <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country_id => $country_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($country_id); ?>"><?php echo e($country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      </div>
                      <div class="form-group">
                        <select name="state" id="state">
                            <option value="">Select State</option>;
                            
                        </select>
                        </div>
                   
                      <br>
                      <div class="form-group">
                          <div>
                              <button type="submit" class="btn btn-success">Submit</button>
                          </div>
                      </div>
                  </form>
              </div>
          </div>
      </div>
  </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script>
     function editStudent(id)
     {
      $.get('/edit/'+id,function(data){
        $('#id').val(data.id);
        $('#fname').val(data.fname);
        $('#lname').val(data.lname);
        $('#email').val(data.email);
        $('#country').val(data.country_id);
        
        $('#studentEditModal').modal('toggle');
      })
     }

    $("#studentEditForm").submit(function(e){
      e.preventDefault();

      let id= $("#id").val();
      let fname= $("#fname").val();
      let lname= $("#lname").val();
      let email= $("#email").val();
      let country= $('#country').val();
      let state= $('#state').val();
     

      $.ajax({
        url:"<?php echo e(route('user-update')); ?>",
        type:"PUT",
        data:{
          "_token":"<?php echo e(csrf_token()); ?>",
          id:id,
          fname:fname,
          lname:lname,
          email:email,
          country:country,
          state:state
          
        },
        dataType:"json",
        success:function(response){
          if(response){
            $("#studentEditModal").modal("hide");
          }
        }
      })
    });

    $(document).ready(function(){
      $('#country').change(function(event){
        var idCountry= this.value;
        if(idCountry){

        $.ajax({
          url:'/state/' + idCountry,
          type: 'GET',
          dataType: 'json',
          //data:{country_id: idCountry,_token:"<?php echo e(csrf_token()); ?>"},
          success: function(response){
            console.log(response);
            $('#state').html('<option value="">Select State</option>');
            $.each(response.state,function(showPage, val){
              $('#state').append('<option value="'+val['id']+'">'+val['state_name']+'</option>')
            });
          

          }
        })
      }
      
      })
    });

    </script>
  </body>
</html><?php /**PATH D:\xampp\htdocs\project-2\resources\views/auth/dashboard.blade.php ENDPATH**/ ?>