<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\User;
use App\Models\country;
use Session;
use Hash;


class CustomController extends Controller
{
    public function login(){
        return view("auth.login");
    }

    public function registration(){
        return view ("auth.registration");
    }

    public function registerUser(Request $request){
        $request->validate([
            'fname'=>'required',
            'lname'=>'required',
            'email'=>'required|email|unique:users',
            'password'=>'required|min:5|max:12',
            'country_id' => 'required|exists:countries,country_id',
        ]);

        $user= new User();
        $user->id= $request->id;
        $user->fname= $request->fname;
        $user->lname= $request->lname; 
        $user->email= $request->email; 
        $user->password= Hash::make($request->password);
        $user->country_id = $request->country_id ;
        $user->save();
        return back()->with('message', 'Registration successful');
        
        
        

        
    
        
        
    }

    public function loginUser(Request $request)
    {
        $request->validate([

            'email'=>'required|email',
            'password'=>'required|min:5|max:12'
        ]);
        $user= User::where('email','=',$request->email)->first();
        if($user){
            if(Hash::check($request->password, $user->password)){
                $request->session()->put('loginID', $user->id);
                return redirect('dashboard');
            }else{
                return back()->with('fail','no match');
            }
        }else{
            return back()->with('fail',' This email not registered');
        }
    }

    public function dashboard()
    {
        $data = array();
        if(Session::has('loginID')){
            $data= User::with('country')->where('id','=', Session::get('loginID'))->first();
            $country = Country::pluck('country_name','country_id');
            
          
        }
        return view('auth.dashboard', compact('data','country'));
    }

    public function logout(){
        if(Session::has('loginID')){
            Session::pull('loginID');
            return redirect('login');
        }
    }

    public function showPage()
    {
        $countries = Country::pluck('country_name','country_id');
        


        
        return view('auth.registration', compact('countries'));

    }

    public function state($idCountry)
    {
        $data= State::where('country_id',$country_id)->get();
        return response()->json($data);
    }

    public function getStudentById($id)
    {
        $user= User::find($id);
        return response()->json($user);
        
    }

    public function updateStudent(Request $request)
    {
        $user= User::find($request->id);
        $user->fname= $request->fname;
        $user->lname= $request->lname; 
        $user->email= $request->email;
        $user->country_id= $request->country; 
        $user->save();
        return response()->json($user);
    }

  
}
