<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.4/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.4/dist/sweetalert2.min.css">
  </head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4" style="margin-top: 20px" >
                <h1>Resgistration</h1>
                <hr>
                <form action="{{route('register-user')}}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="name"> First Name</label>
                        <input type="text" name="fname" value="" class="form-control" placeholder="Enter your name">
                        
                        <br>
                    </div>
                    <div class="form-group">
                        <label for="name"> Last Name</label>
                        <input type="text" name="lname" value="" class="form-control" placeholder="Enter your Last name">
                        
                        <br>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" value="" class="form-control" placeholder="Enter your email">
                      
                        <br>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" value="" class="form-control" placeholder="Enter your password">
                        
                        <br>
                    </div>
                    <div class="form-group">
                    <select name="country_id">
                        <option value="" disabled selected>{{'Select Country'}}</option>;
                        @foreach ($countries as $country_id => $country_name)
                            <option value="{{ $country_id }}">{{ $country_name }}</option>
                        @endforeach
                    </select>
                    </div>
                    <br>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Register</button>
                    </div>
                    <br>
                    <a href="login">Already a user? Login</a>
                    
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    @if($errors->any())
    <script>
        Swal.fire({
            icon: 'error',
            text: '{!! implode('', $errors->all(':message'))!!}',
        })
    </script>
    @endif


    @if(Session::has('message'))
    <script>
        Swal.fire({
            icon: 'success',
            title: '{{ session('message') }}',
            text: 'Your data has been inserted.',
            showConfirmButton: false,
            timer: 3000, // Use 'timer' instead of 'time' to specify the duration
            onClose: function() {
                window.location.href = '/login'; // Redirect to the login page
            }
        });
        
        // Redirect to the login page after 3 seconds
        setTimeout(function() {
            window.location.href = '/login';
        }, 3000);
    </script>
@endif 
</body>
</html>